<ul class="nav nav-tabs tab-nav-right" role="tablist">
    <li role="presentation" class="active">
        <a href="#information" data-toggle="tab" aria-expanded="false">{!! trans("admin_branch.tab.information") !!}</a>
    </li>

    <li role="presentation">
        <a href="#location" data-toggle="tab" aria-expanded="false">{!! trans("admin_branch.tab.location") !!}</a>
    </li>
</ul>