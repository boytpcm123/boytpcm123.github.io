<ul class="nav nav-tabs tab-nav-right" role="tablist">
    <li role="presentation" class="active">
        <a href="#information" data-toggle="tab" aria-expanded="false">{!! trans("admin_user.tab.information") !!}</a>
    </li>

    <li role="presentation">
        <a href="#permission" data-toggle="tab" aria-expanded="false">{!! trans("admin_user.tab.permission") !!}</a>
    </li>
    <li role="presentation">
        <a href="#userinfo" data-toggle="tab" aria-expanded="false">{!! trans("admin_user.tab.userinfo") !!}</a>
    </li>
</ul>