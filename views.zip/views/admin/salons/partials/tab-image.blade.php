<div class="form-group">
    <input type="file" class="salon_images" name="salon_images[]" multiple accept="image/*">
</div>