<div class="clearfix"></div>
<hr>
<div class="row">
    <div class="col-sm-9">
        <button type="submit" class="btn btn-primary waves-effect">{!! trans("button.save") !!}</button>
        <a href="" class="btn btn-default waves-effect">{!! trans("button.reset") !!}</a>
    </div>
    <div class="col-sm-3 text-right">
        <a href="{!! $cancel !!}" class="btn btn-danger waves-effect">{!! trans("button.cancel") !!}</a>
    </div>
</div>