<ul class="nav nav-tabs tab-nav-right" role="tablist">
    <li role="presentation" class="active">
        <a href="#information" data-toggle="tab" aria-expanded="false">General</a>
    </li>

    <li role="presentation">
        <a href="#photos" data-toggle="tab" aria-expanded="false">Media</a>
    </li>
</ul>