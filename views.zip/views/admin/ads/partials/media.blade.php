<div class="form-group">
    <input type="file" class="ad_files" name="ad_files[]" multiple>
</div>