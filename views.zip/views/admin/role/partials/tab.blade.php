<ul class="nav nav-tabs tab-nav-right" role="tablist">
    <li role="presentation" class="active">
        <a href="#information" data-toggle="tab" aria-expanded="false">{!! trans("admin_role.tab.information") !!}</a>
    </li>

    <li role="presentation">
        <a href="#permission" data-toggle="tab" aria-expanded="false">{!! trans("admin_role.tab.permission") !!}</a>
    </li>
</ul>