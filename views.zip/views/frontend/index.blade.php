@extends('frontend.layouts.master')
@section('content')
<h1>API</h1>
@endsection